language: pt

Funcionalidade: Fazer Checkout
Como cliente da EBAC-SHOP
Quero fazer concluir meu cadastro
Para finalizar minha compra

Contexto:
Dado que eu faça o checkout no portal EBAC-SHOP

Cenário: Cadastro válido
Quando eu digitar o nome "Danieli", sobrenome "Pessini", país "Brasil", endereço "Rua Trindade", cidade "Osasco", CEP "012345-000", telefone "(11)898989898"
E o email "danieli@ebacshop.com.br"
Então deve permitir clicar no link "Finalizar a compra"

Cenário: Usuário com email inválido
Quando eu preencher o campo um com email com o dado inválido "danieli!ebacshop.com.br"
E clicar no link "Finalizar a compra"
Então deve exibir uma mensagem de alerta "Email inválido"

Cenário: Usuário com dados em branco
Quando eu não digitar o nome "Danieli"
E clicar no link "Finalizar a compra"
Então deve exibir uma mensagem de alerta: "Preencher os campos obrigatórios"

Esquema do Cenário: Autenticar multiplos cadastros
Quando eu digitar o <nome>, <sobrenome>, <país>, <endereço>, <cidade>, <CEP>, <telefone>
E o <email>
Então deve permitir "Finalizar a compra" 

Exemplos:
|nome|sobrenome|país|endereço|cidade|CEP|telefone|email|
|"Danieli"|"pessini"|"Brasil"|"Rua Trindade"|"Osasco"|"012345-000"|"(11)898989898"|"danieli@ebacshop.com.br"|
|"Samuel|"Costa"|"Brasil"|"Rua Trindade"|"Osasco"|"012345-000"|"(11)898989898"|"danieli@ebacshop.com.br"|
|"Douglas"|"Prado"|"Brasil"|"Rua Trindade"|"Osasco"|"012345-000"|"(11)898989898"|"danieli@ebacshop.com.br"|
|"Marcelo|"Bernardo"|"Brasil"|"Rua Trindade"|"Osasco"|"012345-000"|"(11)898989898"|"danieli@ebacshop.com.br"|
