language: pt

Funcionalidade: Configurar produto
Como cliente da EBAC-SHOP
Quero configurar meu produto de acordo com meu tamanho e gosto
E escolher a quantidade 
Para depois inserir no carrinho 

Contexto:
Dado que eu acesse a tela de produtos da EBAC-SHOP

Cenário: Compra válida
Quando eu selecionar a cor "azul", tamanho "42"
E a quantidade "9"
Então deve clicar no botão comprar e exibir mensagem: "Finalizar compra"
Ou se clicar no botão "limpar" deve voltar ao estado original

Cenário: Compra inexistente
Quando eu selecionar a cor "bege", tamanho "50"
E a quantidade "0"
Então deve clicar no botão comprar e exibir a mensagem: "Quantidade insuficiente"

Cenário: Compra inválida
Quando eu selecionar a cor "azul", tamanho "42"
E a quantidade "11"
Então deve clicar no botão comprar e exibir a mensagem: "Quantidade inválida"

Esquema do Cenário: Autenticar multiplas compras
Quando eu digitar a <cor> e o <tamanho>
E a <quantidade>
Então deve exibir a <mensagem> de sucesso

Exemplos:
|cor|tamanho|quantidade|mensagem|
|"azul"|"42"|"2"|"Finalizar compra"|
|"preto"|"40"|"8"|"Finalizar compra"|
|"vermelho"|"40"|"5"|"Finalizar compra"|
|"verde"|"38"|"7"|"Finalizar compra"|