language: pt

Funcionalidade: Login na Plataforma
Como cliente da EBAC-SHOP
Quero fazer o login na plataforma
Para visualizar meus pedidos

Contexto:
Dado que eu acesse a página de autenticação do portal EBAC-SHOP

Cenário: Autenticação válida
Quando eu digitar o usuário "danieli@ebacshop.com.br"
E a senha "ebac@123"
Então deve exibir uma mensagem de alerta: "Olá Danieli"
Ou direcionar para a tela de checkout "Sair"


Cenário: Usuário inexistente
Quando eu digitar o usuário "dario@ebacshop.com.br"
E a senha "abc%%%"
Então deve exibir uma mensagem de alerta: "Usuário inexistente"

Cenário: Usuário com senha inválida
Quando eu digitar o usuário "danieli@ebacshop.com.br"
E a senha "000123"
Então deve exibir uma mensagem de alerta: "Usuário ou senha inválidos"

Esquema do Cenário: Autenticar multiplos usuários
Quando eu digitar o <usuário>
E a <senha>
Então deve exibir a <mensagem> de sucesso
Ou direcionar para a tela de <checkout>

Exemplos:
|usuarios|senha|mensagem|checkout|
|"danieli@ebacshop.com.br"|"ebac@123"|"Olá Danieli"|"Sair"|
|"samuel@ebacshop.com.br"|"ebac@123"|"Olá Samuel"|"Sair"|
|"douglas@ebacshop.com.br"|"ebac@123"|"Olá Douglas"|"Sair"|
|"marcelo@ebacshop.com.br"|"ebac@123"|"Olá Marcelo"|"Sair"|
